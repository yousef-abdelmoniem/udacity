package org.example.pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class P01_register {
    public WebElement registerlink()
    {
        return Hooks.driver.findElement(By.className("ico-register"));
    }

    public WebElement genderButton(){
        return Hooks.driver.findElement(By.cssSelector("div[id=\"gender\"] input[type=\"radio\"]"));
    }
    public WebElement firstNames(){
        return Hooks.driver.findElement(By.cssSelector("input[data-val-required=\"First name is required.\"]"));
    }
    public WebElement secondNames(){
        return Hooks.driver.findElement(By.cssSelector("input[data-val-required=\"Last name is required.\"]"));
    }
    public Select dateofDay(){
        Select select = new Select(Hooks.driver.findElement(By.name("DateOfBirthDay")));
        return select;
    }
    public Select dateofMonth(){
        Select select1 = new Select(Hooks.driver.findElement(By.name("DateOfBirthMonth")));
        return select1;
    }
    public Select dateofYear(){
        Select select3 = new Select(Hooks.driver.findElement(By.name("DateOfBirthYear")));
        return select3;

    }
    public WebElement mail(){
        return Hooks.driver.findElement(By.cssSelector("input[type=\"email\"]"));
    }
    public WebElement password(){
        return Hooks.driver.findElement(By.cssSelector("input[type=\"password\"]"));
    }
    public WebElement confirmPassword() {
        return Hooks.driver.findElement(By.id("ConfirmPassword"));
    }
    public WebElement registerButton(){
        return Hooks.driver.findElement(By.name("register-button"));
    }
    public WebDriver page(){
        return Hooks.driver;
    }

}


