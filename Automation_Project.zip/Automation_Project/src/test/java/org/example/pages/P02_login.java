package org.example.pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P02_login {
    public WebElement loginPage(){
        return Hooks.driver.findElement(By.className("ico-login"));
    }

    public WebElement email(){
        return Hooks.driver.findElement(By.className("email"));

    }
    public WebElement password(){
        return Hooks.driver.findElement(By.className("password"));
    }
    public WebElement loginButton(){
        return Hooks.driver.findElement(By.cssSelector("div[class=\"buttons\"] [type=\"submit\"]"));
    }
    public WebDriver page(){
        return Hooks.driver;
    }

}
