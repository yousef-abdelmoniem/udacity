package org.example.pages;

import io.cucumber.java.eo.Se;
import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class P03_homePage {
    public WebDriver homePage(){
        return Hooks.driver;
    }

    public Select currency(){
        Select select = new Select(Hooks.driver.findElement(By.id("customerCurrency")));
        return select;
    }
    public WebDriver page(){
        return Hooks.driver;
    }

    public WebElement search(){
       return Hooks.driver.findElement(By.cssSelector("input[class=\"search-box-text ui-autocomplete-input\"]"));
    }




}
