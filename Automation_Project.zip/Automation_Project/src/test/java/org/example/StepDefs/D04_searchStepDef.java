package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class D04_searchStepDef {
    P03_homePage searching = new P03_homePage();
    @When("user enter product name as {string}")
    public void user_enter_product_name_as(String string) {
        searching.search().sendKeys(string);

    }
    @And("enter the search key")
    public void enter_the_search_key() {
        searching.search().sendKeys(Keys.ENTER);

    }
    @Then("search is completed")
    public void search_is_completed() {
        SoftAssert soft = new SoftAssert();
        soft.assertTrue(searching.page().getCurrentUrl().contains("searching.page()"));
        List<WebElement> list = searching.page().findElements(By.className("product-title"));
        System.out.println(list.size());





    }


}
