package org.example.StepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class D05_hoverCategoriesStepDef {
    P03_homePage hover = new P03_homePage();
    Actions act = new Actions(Hooks.driver);
    WebElement element = hover.homePage().findElement(By.cssSelector("img[src=\"https://demo.nopcommerce.com/images/thumbs/0000009_apparel_450.jpeg\"]"));
    @When("user click on one of the categories")
    public void user_click_on_one_of_the_categories() {

        act.moveToElement(element).perform();



    }
    @Then("check if the selected sub-category contains {int} other")
    public void check_if_the_selected_sub_category_contains_other(Integer int1) throws InterruptedException {
        act.moveToElement(element).click(element).build();
Thread.sleep(3000);
    }
}
