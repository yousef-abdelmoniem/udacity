package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P02_login;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.testng.asserts.SoftAssert;

public class D02_loginStepDef {
    P02_login login = new P02_login();
    @Given("user go to login page")
    public void user_go_to_login_page() {
        login.loginPage().click();

    }
    @When("user login with valid {string} and {string}")
    public void userLoginWithValidAnd(String arg0, String arg1) {
        arg0="test111@example.com";
        arg1="P@ssw0rd";
        login.email().sendKeys(arg0);
        login.password().sendKeys(arg1);
    }
    @And("user press on login button")
    public void user_press_on_login_button() {
        login.loginButton().click();

    }
    @Then("user login to the system successfully")
    public void user_login_to_the_system_successfully() {
        SoftAssert soft = new SoftAssert();
        soft.assertEquals(login.page().getCurrentUrl(),"https://demo.nopcommerce.com/");
        soft.assertTrue(login.page().getPageSource().contains("My account"));
        soft.assertAll();

    }


    @When("user login with {string} and {string}")
    public void userLoginWithAnd(String arg1, String arg2) {
        arg1="test1111@example.com";
        arg2="pass@word";
        login.email().sendKeys(arg1);
        login.password().sendKeys(arg2);

    }

    @Then("user could not login to the system")
    public void userCouldNotLoginToTheSystem() {
        SoftAssert soft = new SoftAssert();
        soft.assertTrue(login.page().getPageSource().contains("Login was unsuccessful"));
        String color=login.page().findElement(By.xpath("//div[@class=\"message-error validation-summary-errors\"]")).getCssValue("color");
        color= Color.fromString(color).asHex();
        soft.assertEquals(color,"#e4434b");
        soft.assertAll();
    }
}
