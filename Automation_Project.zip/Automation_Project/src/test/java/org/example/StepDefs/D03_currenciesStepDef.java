package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

public class D03_currenciesStepDef {
    P03_homePage homePage = new P03_homePage();
    @Given("user enter the home page")
    public void user_enter_the_home_page() {
        homePage.homePage();
    }

    @When("user press on the dropdown list and select euro")
    public void userPressOnTheDropdownListAndSelectEuro() {
        homePage.currency().selectByIndex(1);

    }
    @Then("user check if it is applied to the home page")
    public void user_check_if_it_is_applied_to_the_home_page() {

        List<WebElement> elements = homePage.page().findElements(By.cssSelector("span[class=\"price actual-price\"]"));
        for(int i = 0; i<elements.size()-1;i++)
        Assert.assertTrue(elements.get(i).getText().contains("€"));


        }

    }




