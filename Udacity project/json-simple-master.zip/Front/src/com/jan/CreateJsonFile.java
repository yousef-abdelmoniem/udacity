package com.jan;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@SuppressWarnings("deprecation")
public class CreateJsonFile {
	public CreateJsonFile() {}
	@SuppressWarnings("unchecked")
	public JSONObject generateRandomArray() {
		int max = 15;
		int min =1 ;
		JSONObject object =new JSONObject();
		Random rand = new Random();
		JSONArray array = new JSONArray();
//		array.add(String.valueOf(rand.nextInt(max-min)+min));
//		array.add(String.valueOf(rand.nextInt(max-min)+min));
//		array.add(String.valueOf(rand.nextInt(max-min)+min));
//		array.add(String.valueOf(rand.nextInt(max-min)+min));
//		array.add(String.valueOf(rand.nextInt(max-min)+min));
//		object.put("courses", array);
//		
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		object.put("courses", array);
		
		return object;
		
		
//		int []coursesArray = new int[5];
//		int max = 15;
//		int min =1;
//		Random rand = new Random();
//		for(int i = 0 ; i<coursesArray.length;i++)  {
//			 coursesArray[i]=rand.nextInt(max-min)+min;
		
//		}
//		return(coursesArray);
	}
	@SuppressWarnings({ "null", "unchecked" })
//	public String removeDuplictae() {
//		JSONArray x = generateRandomArray();
//		int []c = new int [5];
//		String y="";
//		for(int i =0 ; i<x.length;i++) {
//			for(int j=0;j<x.length;j++) {
//				if(i==j)
//					y="1";
//				else if(x[i]!=x[j]){
//					c[i]=x[i];
//					
//					
//				}
//			}
//		} 
//		return(Arrays.toString(c));
//		
//	}
	public void goJson() throws IOException {
		File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentcoursedata2.json");
		FileWriter writer = new FileWriter(file1);
		
		JSONObject object = new JSONObject();
		
		for(int i= 1 ; i<100;i++) {

	    	String cast=String.valueOf(i);
	    	 
	    	JSONObject generated = generateRandomArray();
	    	object.put(object.put("Id",i),generated);
			
			
		}
	    System.out.print(object.toJSONString());
	    
	    
        try (PrintWriter out = new PrintWriter(writer)) {
				out.println(object);
				}
		
		
		
		
	}

	
}
