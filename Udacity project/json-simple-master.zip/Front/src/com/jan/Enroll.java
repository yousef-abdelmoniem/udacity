package com.jan;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Enroll {
	public Enroll() {}
	public void checkCourses(){
		String d="";
		Course c = new Course();
		Student s = new Student();
		String[] data=c.getJSON();
		String id=s.getId();
		for(int i = 0;i<data.length;i++) {
			
			if(data[i].contains(id)) {
			   d = data[i];
			   String[] c1= d.split("courses");
			   System.out.println(Arrays.toString(c1));
				
		}
			
			
		
		
		
		
	}
	

}
	public void getStudentCourses() throws IOException{
		Course c = new Course();
		Student s = new Student();
		System.out.println("================================================================================");
		System.out.println("Student Details page");
		System.out.println("================================================================================");
		System.out.print(s.getCsv());
		System.out.println("--------------------------------------------------------------------------------");
		System.out.println("Enroll courses");
		System.out.println("1-" + c.getCsv());
		
		
		
	}
	public void noCourses() throws IOException {
		Student s = new Student();
		System.out.println("================================================================================");
		System.out.println("Student Details page");
		System.out.println("================================================================================");
		System.out.print(s.getCsv());
		System.out.println("--------------------------------------------------------------------------------");
		System.out.print("This student hasn't enrolled in any courses");
	}
	public void createStudentJson() {
		File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\enroll.json");
		try {
			JSONArray Array = new JSONArray();
			Course c = new Course();
			Student s = new Student();
			FileWriter writer = new FileWriter(file1);
			JSONObject object = new JSONObject();
			Object JSONArray;
			for(int i = 1 ; i<6;i++) {
			 Array.add(c.getId());
			}
			object.put(s.getId(), Array);
			try (PrintWriter out = new PrintWriter(writer)) {
				out.println(object);
				}
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void removeFromJson() throws FileNotFoundException, IOException, ParseException {
//		Course c = new Course();
//		File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\enroll.json");
//		FileWriter writer = new FileWriter(file1);
//		JSONParser parser = new JSONParser();
//		Object x = parser.parse(new FileReader(file1));
//		JSONObject Object = (JSONObject)x;
//		JSONArray array = (JSONArray)Object.get(x);
//		array.remove(c.getId());
//		System.out.print(array);
//		try (PrintWriter out = new PrintWriter(writer)) {
//			out.println(Object);
//			}
		Course c = new Course();
		Student s = new Student();
		JSONObject object = new JSONObject();
		JSONArray Array = null;
		Scanner sc = new Scanner(System.in);
		int maxCourses= sc.nextInt();
		for(int i = 1 ; i<maxCourses;i++) {
		 Array.add(c.getId());
		}
//		object.put(s.getId(), Array);
		File file = new File(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\enroll.json").toString());
		file.setWritable(true);
		BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\enroll.json").toString()));
		bufferedOutputStream.write(("{}").getBytes());
		bufferedOutputStream.flush();
	
		
	}
	}
