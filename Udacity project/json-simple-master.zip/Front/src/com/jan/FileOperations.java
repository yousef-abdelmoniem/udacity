package com.jan;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;




public class FileOperations {
	File file = new File("src\\coursedata.xml");
	public FileOperations() {}
	@SuppressWarnings("resource")
	public void createCSVfromXML(File file) throws IOException, ParserConfigurationException {
		 this.file= file;
		 String data="";
		 String coursedata="";
		 FileReader fr=new FileReader(file);
		 File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\course.csv");
		 FileWriter writer = new FileWriter(file1);
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder builder = factory.newDocumentBuilder();
		 try {
			Document document = builder.parse("src\\coursedata.xml");
			document.getDocumentElement().normalize();
			 
			//Here comes the root node
			Element root = document.getDocumentElement();
			NodeList nList = document.getElementsByTagName("row");
			String x= "id,coursename,instructor,courseduration,coursetime,location";
			System.out.println("id,coursename,instructor,courseduration,coursetime,location");
			for (int temp = 0; temp < nList.getLength(); temp++)
			{
			 Node node = nList.item(temp);
			 System.out.println();    
			 if (node.getNodeType() == Node.ELEMENT_NODE)
			 {
			    Element eElement = (Element) node;
			    String a=eElement.getElementsByTagName("id").item(0).getTextContent()+",";
			    String b=eElement.getElementsByTagName("CourseName").item(0).getTextContent()+",";
			    String c=eElement.getElementsByTagName("Instructor").item(0).getTextContent()+",";
			    String d=eElement.getElementsByTagName("CourseDuration").item(0).getTextContent()+",";
			    String e=eElement.getElementsByTagName("CourseTime").item(0).getTextContent()+",";
			    String f=eElement.getElementsByTagName("Location").item(0).getTextContent();
			    data=a+b+c+d+e+f;
			    coursedata=coursedata+"\n"+data;
			    System.out.printf(data);
			 }
			 
	  				}
			try (PrintWriter out = new PrintWriter(writer)) {
  				out.println(coursedata);
			 }   
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         

         

		} 
	
	
	

	@SuppressWarnings("resource")
	public void createFilefromTXT(File file) {
		String data = "";
		this.file=file;
		Scanner sc = new Scanner(System.in);
		
		try {
			File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv");
			FileWriter writer = new FileWriter(file1);
			sc = new Scanner(file);
			 while (sc.hasNextLine()) {
	                String line = sc.nextLine();
	                System.out.println("--------------");
	                System.out.println("Student data");
	                System.out.println("--------------");
	                String backSlash= line.replace("$", "\n");
//	                System.out.println(backSlash);
	                data = backSlash.replace("#", ",");
	                System.out.printf(data);
	                
	                
			 }
			 sc.close();
			 try (PrintWriter out = new PrintWriter(writer)) {
  				out.println(data);
  				}
			 
			
			 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
			
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}
	
		
		
	

}
