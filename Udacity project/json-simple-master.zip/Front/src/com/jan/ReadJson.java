package com.jan;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class ReadJson {
//	@SuppressWarnings("unchecked")
//	public void getData() throws IOException {
//		
//		@SuppressWarnings("deprecation")
//		
//		JSONParser parser = new JSONParser();
//		
//		try {
//			
//		
//			@SuppressWarnings("deprecation")
//			Object x = parser.parse(new FileReader("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentcoursedata.json"));
//			JSONObject Object = (JSONObject)x;
//			String id = (String)Object.get("person id");
//			@SuppressWarnings("deprecation")
//			
////			System.out.print(courses.get(1));
////			System.out.println("id: " + 1);
////	        System.out.println( courses);
//			JSONArray courses =(JSONArray)Object.get("courses");
//	        Iterator<String> iterator=courses.iterator();
//	        while(iterator.hasNext()) {
//	        	if(courses.isEmpty()) {
//	        		System.out.print("cant find it");
//	        		
//	        	}else                               
//	        	System.out.println("courses: " + iterator.next());
//	        
//	        }
//		
//		
//		
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//
//		
//		}
	public void openJson() throws FileNotFoundException {
		File file2=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv");
		File file1=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\course.csv");
		GenerateCsvData c = new GenerateCsvData();
		GenerateCsvData b = new GenerateCsvData();
//		String students= c.listData(file2);
//		String courses= b.listData(file1);
		
		File file = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentcoursedata.json");
		String line="";
		Scanner sc = new Scanner(System.in);
		sc=new Scanner(file);
		while(sc.hasNext()) {
			line = sc.nextLine();		
			}
//		System.out.print(line);
		String a="{";	
		String d="}";
		int left=line.indexOf(a);
		int right=line.indexOf(d);
		
		for(int i =0 ; i<line.length();i++) {
			String ret [] = line.split(":");
			for(String part: ret) {
	            System.out.println(part);
	        }
			
//			System.out.println(part);
			
//			
//			System.out.print(ret);
//			System.out.println();
		}
		
		
		
	}
	}

