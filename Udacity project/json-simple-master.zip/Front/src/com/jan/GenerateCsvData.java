package com.jan;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.Scanner;

public class GenerateCsvData {
	String studentdata="";
	File file=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv");
	public GenerateCsvData() {}
	
	public String listData(File file) {
		this.file=file;
		Scanner sc = new Scanner(System.in);
		try {
			sc= new Scanner(file);
			System.out.println("---------------");
			System.out.println("Student data");
			System.out.println("---------------");
			while(sc.hasNext()) {
				
				
				studentdata=sc.nextLine();
				System.out.printf("%20s",studentdata);
				System.out.println();
				
			}
			sc.close();
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentdata;
		
		
		
	}


}